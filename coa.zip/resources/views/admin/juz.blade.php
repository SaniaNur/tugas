 @extends('admin.app')

@section('content')
<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Daftar Juz</h2>    
                    </div>
                </div>
                <div class="row">
                <div class="col-md-12">
                    <!-- Advanced Tables -->
                    <div class="panel panel-default">
                        
                        <div class="panel-body">
                            <div class="table-responsive">
                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Juz</th>
                                            <th>Surah</th>
                                            <th>Jumlah Ayat</th>
                                            
                                        </tr>
                                    </thead>
                                    
                                </table>
                            </div>
                            
                        </div>
                    </div>
                    <!--End Advanced Tables -->
                </div>
            </div>              
         </div>
                   
                  </div>
                      
                 <!-- /. ROW  -->                         
                 <!-- /. ROW  -->           
@endsection   
                 <!-- /. ROW  -->           