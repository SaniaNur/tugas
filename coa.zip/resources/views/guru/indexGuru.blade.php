@extends('admin.app')

@section('content')
<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>SELAMAT DATANG !</h2>   
                        
                    </div>
                </div>              
                 <!-- /. ROW  -->
                  <hr />
                 <div class="row" >
                <div class="col-md-6 col-sm-6 col-xs-6"> 
                <div class="panel panel-back noti-box text-center" >
                  <i class="fa fa-users" style="font-size:50px" ></i>
                <div class="text-box" >
                    <h3>Data Siswa</h3>
                    <h2>8</h2>
                </div>
             </div>

@endsection