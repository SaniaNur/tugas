<?php $__env->startSection('header'); ?>
    <section class="content-header">
      <h1>
        <?php echo e(trans('backpack::base.dashboard')); ?><small><?php echo e(trans('backpack::base.first_page_you_see')); ?></small>
      </h1>
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/dashboard')); ?>">AR</a></li>
        <li class="active"><?php echo e(trans('backpack::base.dashboard')); ?></li>
      </ol>
    </section>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
    <div id="page-wrapper" >
            <div id="page-inner">
      
                  <hr />
                  <div class="callout callout-success">
                    <h4>Halo <?php echo e(Auth::user()->name); ?>  !</h4>
                    <p>Selamat Datang di Halaman <?php echo e(Auth::user()->level); ?></p>
                  </div>
              <?php if(Auth::user()->level == "Admin"): ?>   
                <div class="row" >
                  <div class="col-md-12" >
                    <div class="col-md-3"></div>
                      <div class="col-md-3 col-xs-6"  >
              <!-- small box -->
                    <div class="small-box bg-red">
                      <div class="inner">
                        <h3><?php echo e($jumlahGuru); ?></h3>
                        <p>Data Guru</p>
                      </div>
                        <div class="icon">
                          <i class="ion ion-person-add"></i>
                        </div>
                          <a href="<?php echo e(url('admin/guru')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                      </div>
                    </div>


                    <div class="col-md-3 col-xs-6">
              <!-- small box -->
                    <div class="small-box bg-red">
                      <div class="inner">
                        <h3><?php echo e($jumlahSiswa); ?></h3>
                        <p>Data Siswa</p>
                      </div>
                        <div class="icon">
                          <i class="ion ion-person-add"></i>
                        </div>
                          <a href="<?php echo e(url('admin/siswa')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                      </div>

                    </div>
                      <div class="col-md-3"></div>
                    </div>

                    <div class="col-md-12" >
                      <div class="col-md-4"></div>
                    <div class="col-md-4 col-xs-6">
              <!-- small box -->
                    <div class="small-box bg-red" style="text-align:center">
                      <div class="inner">
                        <h3><?php echo e($hafalan); ?></h3>
                        <p>Hafalan Hari Ini</p>
                        
                      </div>
                        <div class="icon">
                          <i class="ion ion-pie-graph"></i>
                        </div>
                          <!-- <a href="<?php echo e(url('admin/pencapaian')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
                      </div>

               <?php elseif(Auth::user()->level == "Guru"): ?>
                  <div class="row" >
                  <div class="col-md-12" >
                    <div class="col-md-3"></div>
                      <div class="col-md-3 col-xs-6"  >
              <!-- small box -->
                    <div class="small-box bg-red">
                      <div class="inner">
                        <h3><?php echo e($jumlahSiswa); ?></h3>
                        <p>Data Siswa</p>
                      </div>
                        <div class="icon">
                          <i class="ion ion-person-add"></i>
                        </div>
                          <!-- <a href="<?php echo e(url('guru/pencapaian')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
                      </div>
                    </div>


                    <div class="col-md-3 col-xs-6">
              <!-- small box -->
                    <div class="small-box bg-red">
                      <div class="inner">
                        <h3><?php echo e($hafalan); ?></h3>
                        <p>Hafalan Hari Ini</p>
                      </div>
                        <div class="icon">
                          <i class="ion ion-pie-graph"></i>
                        </div>
                          <!-- <a href="<?php echo e(url('admin/siswa')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a> -->
                      </div>

                    </div>
                      <div class="col-md-3"></div>
                    </div>

                    <div class="col-md-12" >
                      <div class="col-md-4"></div>
                    <div class="col-md-4 col-xs-6">
              <!-- small box -->
                     <div class="small-box bg-red">
                      <div class="inner">
                          <a href="<?php echo e(url('guru/hafalan/create')); ?>" type="button" class="btn btn-block btn-danger btn-lg">INPUT HAFALAN</a>
                      </div>
 
                      </div>
                    </div>
              <?php elseif( Auth::user()->level == "Siswa" ): ?>
                  <div class="row" >
                    <div class="col-md-12" >
                    <div class="col-md-4"></div>
                      <div class="col-md-4 col-xs-6"  >
              
                    <div class="small-box bg-green">
                      <div class="inner" style="text-align:center">
                        <?php 
                            $juz = floor($total[0]->totalPendapatan/20);
                            $lembar = 0.0;
                            $lembar = fmod($total[0]->totalPendapatan, 20)/2; 
                         ?>
                        <h3><?php if($total[0]->totalPendapatan == 0): ?> <?php echo e($total[0]->totalPendapatan); ?> Lembar <?php else: ?> <?php if($juz != 0): ?> <?php echo e($juz); ?>  Juz <?php endif; ?> <?php if($lembar != 0): ?><?php echo e($lembar); ?> Lembar <?php endif; ?> <?php endif; ?></h3>
                        <!-- <h3><?php echo e($total[0]->totalPendapatan); ?></h3> -->

                        <h4>Total Pendapatan</h4>
                      </div>
                        <!-- <div class="icon">
                          <i class="ion ion-person-add"></i>
                        </div> -->
                          <a href="<?php echo e(url('siswa/laporan')); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
                      </div>
                    </div>
                  </div>
                  <div class="col-md-12 ">
                    <div class="tab-pane fade active in" id="grafik">
                                    <h4>Grafik</h4>
                                    <div class="box box-success">
                                        <div class="box-header with-border">
                                          <h3 class="box-title">Bar Chart</h3>

                                          <div class="box-tools pull-right">
                                            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i>
                                            </button>
                                            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-times"></i></button>
                                          </div>
                                        </div>
                                         <?php 
                                            $tahun=\Route::current()->parameter('tahun');
                                         ?>
                                       
                                        <label class="col-md-2 col-sm-2 control-label">Tahun</label>
                                        <div class="col-md-2 col-sm-2">
                                          <select required class="form-control" name="tahunLaporan" id="pilihTahun">
                                          <option disable="disabled" selected="selected" value="0">---Pilih Tahun---</option>
                                          <?php
                                             $thn_skr = date('Y');
                                            for($x=$thn_skr; $x >= 2016; $x--){
                                              ?>
                                                <option <?php if($tahun == $x): ?> <?php echo e('selected'); ?> <?php endif; ?> value="<?php echo $x ?>" url="/tahun=<?php echo e($tahun); ?>"><?php echo $x?></option>
                                            <?php
                                            }
                                            ?>   
                                          </select>
                                        </div>
                                        <div class="box-body">
                                          <div class="chart">
                                            <canvas id="myChart" width="400" height="100"></canvas>
                                          </div>
                                        </div>
                                        <!-- /.box-body -->
                                      </div>
                                </div>
                              </div>
                <?php else: ?>           
                <?php endif; ?>

                    </div>
                  </div>
                  <!-- <div class="col-md-6 col-sm-6 col-xs-6"> 
                    <div class="panel panel-back noti-box text-center" >
                    <i class="fa fa-users" style="font-size:50px" ></i>
                    <div class="text-box" >
                      <h3>Data Guru</h3>
                      <h2><?php echo e($jumlahGuru); ?></h2>
                    </div>
                    </div>
                  </div> -->
                 <!--  <div class="col-md-6 col-sm-6 col-xs-6">           
                    <div class="panel panel-back noti-box text-center">
                      <i class="fa fa-users" style="font-size:50px"></i>
                      <div class="text-box" >
                        <h3>Data Siswa</h3>
                        <h2><?php echo e($jumlahSiswa); ?></h2>
                      </div>
                    </div>
                  </div> -->
                   
                </div>
            </div>
                    
                      
        </div>

        
<?php $__env->stopSection(); ?>
<?php $__env->startSection('after_scripts'); ?>              

  <script src="https://cdnjs.cloudflare.com/ajax/libs/Chart.js/2.6.0/Chart.min.js"></script>
  <script>
  var months = ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"];
  var month = months[new Date().getMonth()];
  var ctx = document.getElementById("myChart");
  var myChart = new Chart(ctx, {
      type: 'bar',
      data: {
          yAxisID:"2",
          labels : ["Januari", "Februari", "Maret", "April", "Mei", "Juni", "Juli", "Agustus", "September", "Oktober", "November", "Desember"],
          datasets: [{
              label: 'Jumlah Hafalan ',
            data: [ 
                <?php 
                  foreach($dataHafalan as $item){ 
                 ?>
                <?php echo e($item['jmlHafalan']); ?>,
            
              <?php } ?>
            ],
              backgroundColor: [
                  'rgba(70, 255, 55, 0.3)',
                  'rgba(70, 255, 55, 0.3)',
                  'rgba(70, 255, 55, 0.3)',
                  'rgba(70, 255, 55, 0.3)',
                  'rgba(70, 255, 55, 0.3)',
                  'rgba(70, 255, 55, 0.3)',
                  'rgba(70, 255, 55, 0.3)',
                  'rgba(70, 255, 55, 0.3)',
                  'rgba(70, 255, 55, 0.3)',
                  'rgba(70, 255, 55, 0.3)',
                  'rgba(70, 255, 55, 0.3)',
                  'rgba(70, 255, 55, 0.3)',
              ],
              borderColor: [
                'rgba(70, 255, 55, 1)',
                'rgba(70, 255, 55, 1)',
                'rgba(70, 255, 55, 1)',
                'rgba(70, 255, 55, 1)',
                'rgba(70, 255, 55, 1)',
                'rgba(70, 255, 55, 1)',
                'rgba(70, 255, 55, 1)',
                'rgba(70, 255, 55, 1)',
                'rgba(70, 255, 55, 1)',
                'rgba(70, 255, 55, 1)',
                'rgba(70, 255, 55, 1)',
                'rgba(70, 255, 55, 1)',
              ],
              borderWidth: 1,
              fill: false,
              pointBackgroundColor:  'rgba(70, 255, 55, 1)',
              pointBorderColor: 'rgba(70, 255, 55, 1)',
          }]
        },
      options: {
          responsive: true,
          title:{
              display:true,
              <?php if($tahun): ?>
                text:'Hafalan Tahun <?php echo e($tahun); ?>',
              <?php else: ?>
                text:'Hafalan Tahun Ini',
              <?php endif; ?>
              fontSize: 20
          },
          tooltips: {
              mode: 'index',
              intersect: false,
              callbacks: {
                  label: function(tooltipItems, data) { 
                   var juz = Math.floor(tooltipItems.yLabel);
                      var lembar =((tooltipItems.yLabel*20) % 20)/2;
                      // Convert the array to a string and format the output
                      //value = value.join('.');
                      return juz + ' juz '+lembar+' lembar';
                  }
              }
          },
          hover: {
              mode: 'nearest',
              intersect: true
          },
          scales: {
              xAxes: [{
                  display: true,
                  scaleLabel: {
                      display: true,
                      labelString: 'Bulan'
                  }
              }],
              yAxes: [{
                  display: true,
                  scaleLabel: {
                      display: true,
                      labelString: 'Juz',
                  },
                  ticks:{
                      suggestedMax: 1,
                      stepSize: 0.1 
                    }
              }],
          },
      }
  });
  </script>

  <script src="<?php echo e(asset('vendor/adminlte/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
  <script src="<?php echo e(asset('vendor/adminlte/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>

  <script>
    $(function () {
      $('#dataTables-example').DataTable({
      });
    });

    $('#pilihTahun').change(function(){
      
      var url= "/tugas/public/siswa/dashboard/tahun="+$(this).val();
      console.log(url);
        window.location = url;
    });
  </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backpack::layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>