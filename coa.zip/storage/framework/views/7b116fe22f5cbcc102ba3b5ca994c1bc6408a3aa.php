<?php 
$juz = floor($entry->{$column['name']}/20);
$lembar = fmod($entry->{$column['name']}, 20)/2;
 ?>

<td><?php if($entry->{$column['name']} == 0): ?> <?php echo e($entry->{$column['name']}); ?> Lembar <?php else: ?> <?php if($juz != 0): ?> <?php echo e($juz); ?>  Juz <?php endif; ?> <?php if($lembar != 0): ?><?php echo e($lembar); ?> Lembar <?php endif; ?> <?php endif; ?></td>