<?php $__env->startSection('before_styles'); ?>
<link href="<?php echo e(asset('vendor/adminlte/plugins/datatables/dataTables.bootstrap.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <section class="content-header">
      <h1>
        <span class="text-capitalize"><?php echo e($crud->entity_name_plural); ?></span>
        <small><?php echo e(trans('backpack::crud.all')); ?> <span class="text-lowercase"><?php echo e($crud->entity_name_plural); ?></span> <?php echo e(trans('backpack::crud.in_the_database')); ?>.</small>
      </h1> 
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url(config('backpack.base.route_prefix'), 'dashboard')); ?>"><?php echo e(trans('backpack::crud.admin')); ?></a></li>
        <li><a href="<?php echo e(url($crud->route)); ?>" class="text-capitalize"><?php echo e($crud->entity_name_plural); ?></a></li>
        <li class="active"><?php echo e(trans('backpack::crud.list')); ?></li>
      </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<!-- Default box -->
  <div class="row">

    <!-- THE ACTUAL CONTENT -->
    <div class="col-md-12">
      <div class="box">
        
                <!-- <ul class="nav nav-tabs">
                    <li class="active"><a class="nav-link">Tabel</a></li>
                    <li><a class="nav-link">Grafik</a></li>
                </ul> -->
              
        <div class="box-header <?php echo e($crud->hasAccess('create')?'with-border':''); ?>">

          <?php echo $__env->make('crud::inc.button_stack', ['stack' => 'top'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <div id="datatable_button_stack" class="pull-right text-right"></div>
        </div>

        <div class="box-body ">
            

       
            <div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                <div class="col-md-6 col-sm-6" style="width:100%">
                    <div class="panel panel-default">
                        <div class="panel-heading">
                            History Hafalan
                        </div>
                        

                            <!-- <div class="tab-content">

                                <div class="tab-pane fade" id="tabel"> --> 
                                    <h4 style="padding-left:10px">Tabel</h4>
                                    <div class="panel panel-default">
                                        <div class="panel-body">
                                            <div class="table-responsive">
                                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                                    <thead>
                                                        <center>
                                                        <tr>
                                                            <th rowspan="2" style="vertical-align:top">No</th>
                                                            <th rowspan="2" style="vertical-align:top">Tanggal</th>
                                                            <th colspan="4" style="text-align:center;">Ziadah</th>
                                                            
                                                            <th colspan="4" style="text-align:center;">Murojaah</th>
                                                            
                                                        </tr>
                                                        <tr>
                                                            <th>Juz</th>

                                                            <th>Dari</th>
                                                            <th>Sampai</th>
                                                            <th>Nilai</th>
                                                            <th>Juz</th>

                                                            <th>Dari</th>
                                                            <th>Sampai</th>
                                                            <th>Nilai</th>
                                                            
                                                        </tr>
                                                    </center>
                                                    </thead>
                                                    <tbody>
                                                        <?php 
                                                        $i=1;
                                                         ?>
                                                        <?php $__currentLoopData = $crud->jenisHafalan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                          <tr>
                                                        <td><?php echo e($i); ?></td>
                                                        <?php if($data->tglziadah!=null): ?>

                                                        <td><?php echo e(\Carbon\Carbon::parse($data->tglziadah)->format('d M Y')); ?></td>
                                                        <?php else: ?>
                                                        <td><?php echo e(\Carbon\Carbon::parse($data->tglM)->format('d M Y')); ?></td>
                                                        <?php endif; ?>
                                                        <td><?php if($data->juzZiadah): ?>
                                                          <?php echo e($data->juzZiadah); ?> 
                                                          <?php else: ?>
                                                          -
                                                          <?php endif; ?>
                                                        </td>
                                                        <td><?php if($data->hlmAZiadah): ?>
                                                          <?php echo e($data->hlmAZiadah); ?>

                                                          <?php else: ?>
                                                          -
                                                          <?php endif; ?>
                                                        </td>
                                                        <td><?php if($data->hlmBZiadah): ?>
                                                          <?php echo e($data->hlmBZiadah); ?>

                                                           <?php else: ?>
                                                          -
                                                          <?php endif; ?>
                                                        </td>
                                                        <td><?php if($data->nilaiZ): ?>
                                                          <?php echo e($data->nilaiZ); ?>

                                                          <?php else: ?>
                                                          -
                                                          <?php endif; ?>
                                                        </td>
                                                        
                                                        <td>
                                                            <?php if($data->juzM): ?>
                                                          <?php echo e($data->juzM); ?> 
                                                          <?php else: ?>
                                                          -
                                                          <?php endif; ?>
                                                        </td>
                                                        <td><?php if($data->hlmAM): ?>
                                                          <?php echo e($data->hlmAM); ?>

                                                          <?php else: ?>
                                                          -
                                                          <?php endif; ?>
                                                        </td>
                                                        <td><?php if($data->hlmBM): ?>
                                                          <?php echo e($data->hlmBM); ?>

                                                           <?php else: ?>
                                                          -
                                                          <?php endif; ?>
                                                        </td>
                                                        <td><?php if($data->nilaiM): ?>
                                                          <?php echo e($data->nilaiM); ?>

                                                          <?php else: ?>
                                                          -
                                                          <?php endif; ?>
                                                        </td>
                                                        
                                                          </tr>
                                                          <?php 
                                                          $i++
                                                           ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </tbody>
                                                   
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                

                                


                               <!--  </div>
                            </div>
                        </div> -->
                    </div>
                </div>
                   
                  </div>
                  </div>
                    
                      
                    </div>

                    <script src="<?php echo e(asset('vendor/adminlte/plugins/jQuery/jquery-2.2.3.min.js')); ?>"></script>                  
<?php $__env->stopSection(); ?>

                    <!-- // <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script> -->
                    <!-- //<script src="<?php echo e(asset('vendor/adminlte/plugins/jQuery/jquery-2.2.3.min.js')); ?>"></script>-->
                    <?php $__env->startSection('after_scripts'); ?>
                    <script src="<?php echo e(asset('vendor/adminlte/plugins/datatables/jquery.dataTables.min.js')); ?>"></script>
                    <script src="<?php echo e(asset('vendor/adminlte/plugins/datatables/dataTables.bootstrap.min.js')); ?>"></script>

                    <script>
                      $(function () {
                        
                        $('#dataTables-example').DataTable({
                          
                        });
                      });
                      </script>
                                              


                <?php $__env->stopSection(); ?>
             <!-- /. PAGE INNER  -->
    
                    
                      
                    
             <!-- /. PAGE INNER  -->          

                 <!-- /. ROW  -->           
<?php echo $__env->make('backpack::layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>