<?php $__env->startSection('content'); ?>
<div id="page-wrapper" >
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>SELAMAT DATANG !</h2>   
                        
                    </div>
                    <div class="col-md-6 col-sm-12 col-xs-12">                     
                    <div style="margin-top:20px" class="panel panel-default">
                        <div class="panel-heading">
                            Pencapaian Hafalan Siswa
                        </div>
                        <div class="panel-body">
                            <div id="morris-bar-chart"></div>
                        </div>
                    </div>            
                </div>
                </div>              
                 <!-- /. ROW  -->
                 
                   
                  </div>
              </div>
                    
                      
                    </div>
<?php $__env->stopSection(); ?>                
             <!-- /. PAGE INNER  -->
<?php echo $__env->make('admin.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>