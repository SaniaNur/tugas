
<td><?php echo e(str_limit(strip_tags($entry->{$column['name']}), 80, "[...]")); ?></td>