<?php $__env->startSection('before_styles'); ?>
<link href="<?php echo e(asset('vendor/adminlte/plugins/datatables/dataTables.bootstrap.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
    <section class="content-header">
      <h1>
        <span class="text-capitalize"><?php echo e($crud->entity_name_plural); ?></span>
        <small><?php echo e(trans('backpack::crud.all')); ?> <span class="text-lowercase"><?php echo e($crud->entity_name_plural); ?></span> <?php echo e(trans('backpack::crud.in_the_database')); ?>.</small>
      </h1> 
      <ol class="breadcrumb">
        <li><a href="<?php echo e(url(config('backpack.base.route_prefix'), 'dashboard')); ?>"><?php echo e(trans('backpack::crud.admin')); ?></a></li>
        <li><a href="<?php echo e(url($crud->route)); ?>" class="text-capitalize"><?php echo e($crud->entity_name_plural); ?></a></li>
        <li class="active"><?php echo e(trans('backpack::crud.list')); ?></li>
      </ol>
    </section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="row">

    <!-- THE ACTUAL CONTENT -->
    <div class="col-md-12">
      <div class="box"style="padding:16px">
        
                <!-- <ul class="nav nav-tabs">
                    <li class="active"><a class="nav-link">Tabel</a></li>
                    <li><a class="nav-link">Grafik</a></li>
                </ul> -->
              
        <div class="box-header <?php echo e($crud->hasAccess('create')?'with-border':''); ?>">

          <?php echo $__env->make('crud::inc.button_stack', ['stack' => 'top'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

          <div id="datatable_button_stack" class="pull-right text-right"></div>
                                                <?php 
                                                    $tahun_params=\Route::current()->parameter('tahun');
                                                    $bulan_params=\Route::current()->parameter('bulan');
                                                ?>
                                                <label class="col-md-1 col-sm-1 control-label " >Bulan</label>
                                                    <div class="col-md-2 col-sm-2 ">
                                                        <select id="pilihBulan" required class="form-control" name="bulan">
                                                            <option disabled="disabled" selected="selected" value="0">--pilih bulan--</option>
                                                        <?php
                                                        $bln=array(1=>"Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember");
                                                        for($bulan=1; $bulan<=12; $bulan++){
                                                            if ($bulan == $bulan_params) {
                                                                echo "<option value='$bulan' selected>$bln[$bulan]</option>"; 
                                                            } else {
                                                                echo "<option value='$bulan'>$bln[$bulan]</option>"; 
                                                            }
                                                            
                                                        }
                                                        ?>
                                                        </select>
                                                    </div>
                                                <label class="col-md-1 col-sm-1 control-label" >Tahun</label>
                                                    <div class="col-md-2 col-sm-2">
                                                        <select id="pilihTahun" required class="form-control" name="tahun">
                                                            <option disabled="disabled" selected="selected" value="0">---Pilih Tahun---</option>
                                                            <?php
                                                                $thn_skr = date('Y');
                                                                for($x=$thn_skr; $x>=2016; $x--){
                                                                ?>
                                                                <?php if($x == $tahun_params): ?>
                                                                    <option selected value="<?php echo $x?>"><?php echo $x ?></option>
                                                                <?php else: ?> 
                                                                    <option value="<?php echo $x?>"><?php echo $x ?></option>
                                                                <?php endif; ?>
                                                                <?php
                                                                }
                                                                ?>
                                                        </select>
                                                        <br>
                                                    </div>
                                                    <button id="btncari" class="btn btn-default">cari</button>
        </div>

        <div class="box-body table-responsive">
            

       
            
                                            <div class="table-responsive">
                                            
                                                <table class="table table-striped table-bordered table-hover" id="dataTables-example">
                                                    <thead>
                                                        <center>
                                                        <tr>
                                                            <th style="vertical-align:top">No</th>
                                                            <th style="vertical-align:top">NIS</th>
                                                            <th style="vertical-align:top">Nama</th>
                                                            <th style="vertical-align:top">Pendapatan 1 Bulan</th>
                                                            <th style="text-align:center;">Total Pendapatan</th>
                                                            
                                                            
                                                            
                                                        </tr>
                                                       
                                                    </center>
                                                    </thead>
                                                    <tbody>
                                                        <?php $__currentLoopData = $crud->hasil; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <tr>
                                                                <td><?php echo e($key+1); ?></td>
                                                                <td><?php echo e($data['nis']); ?></td>
                                                                <td><?php echo e($data['nama']); ?></td>
                                                                <?php 
                                                                    $juz = floor($data['totalBulan']/20);
                                                                    $lembar = 0.0;
                                                                    $lembar = fmod($data['totalBulan'], 20)/2; 
                                                                 ?>
                                                                <td><?php if($data['totalBulan'] == 0): ?> <?php echo e($data['totalBulan']); ?> Lembar <?php else: ?> <?php if($juz != 0): ?> <?php echo e($juz); ?>  Juz <?php endif; ?> <?php if($lembar != 0): ?><?php echo e($lembar); ?> Lembar <?php endif; ?> <?php endif; ?></td>
                                                                 <?php 
                                                                    $juz = floor($data['totalPendapatan']/20);
                                                                    $lembar = 0.0;
                                                                    $lembar = fmod($data['totalPendapatan'], 20)/2; 
                                                                 ?>
                                                                <td><?php if($data['totalPendapatan'] == 0): ?> <?php echo e($data['totalPendapatan']); ?> Lembar <?php else: ?> <?php if($juz != 0): ?> <?php echo e($juz); ?>  Juz <?php endif; ?> <?php if($lembar != 0): ?><?php echo e($lembar); ?> Lembar <?php endif; ?> <?php endif; ?></td>
                                                            </tr>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
                                                    </tbody>
                                                   
                                                </table>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                                

                                


                               <!--  </div>
                            </div>
                        </div> -->
                    </div>
                </div>
                   
                  </div>
                  </div>
                    
                      
  </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('after_scripts'); ?>
<script src="http://localhost/tugas/public/vendor/adminlte/plugins/datatables/jquery.dataTables.js" type="text/javascript"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/dataTables.buttons.min.js" type="text/javascript"></script>
    <script src="https://cdn.datatables.net/buttons/1.2.2/js/buttons.bootstrap.min.js" type="text/javascript"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jszip/2.5.0/jszip.min.js" type="text/javascript"></script>
    <script src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/pdfmake.min.js" type="text/javascript"></script>
    <script src="//cdn.rawgit.com/bpampuch/pdfmake/0.1.18/build/vfs_fonts.js" type="text/javascript"></script>
    <script src="//cdn.datatables.net/buttons/1.2.2/js/buttons.html5.min.js" type="text/javascript"></script>
    <script src="//cdn.datatables.net/buttons/1.2.2/js/buttons.print.min.js" type="text/javascript"></script>
    <script src="//cdn.datatables.net/buttons/1.2.2/js/buttons.colVis.min.js" type="text/javascript"></script>
    
    <script src="http://localhost/tugas/public/vendor/adminlte/plugins/datatables/dataTables.bootstrap.js" type="text/javascript"></script>
<script>
    
    $('#btncari').click(function(){
      var url = "/tugas/public/<?php echo e($crud->getRoute()); ?>/"+$('#pilihBulan').val()+"/"+$('#pilihTahun').val();
      console.log(url);
        window.location = url;
    });
    
  </script>
<script type="text/javascript">
    jQuery(document).ready(function($) {
        var dtButtons = function(buttons){
            var extended = [];
            for(var i = 0; i < buttons.length; i++){
                var item = {
                    extend: buttons[i],
                    exportOptions: {
                        columns: [':visible']
                    }
                };
                switch(buttons[i]){
                    case 'pdfHtml5':
                    item.orientation = 'portrait';
                    break;
                }
                extended.push(item);
            }
            return extended;
        }
      
        var table = $("#dataTables-example").DataTable({
            "pageLength": 25,
            /* Disable initial sort */
            "aaSorting": [],
            "language": {
                "emptyTable":     "Tidak ada data dalam tabel ini",
                "info":           "Menampilkan _START_ sampai _END_ dari _TOTAL_ Data",
                "infoEmpty":      "Menampilkan 0 sampai 0 dari 0 data",
                "infoFiltered":   "(filtered from MAX total entries)",
                "infoPostFix":    "",
                "thousands":      ",",
                "lengthMenu":     "Tampilkan_MENU_ Data Tiap Halaman",
                "loadingRecords": "Loading...",
                "processing":     "Proses mengambil data...",
                "search":         "Cari: ",
                "zeroRecords":    "No matching records found",
                "paginate": {
                    "first":      "Pertama",
                    "last":       "Terakhir",
                    "next":       "Selanjutnya",
                    "previous":   "Sebelumnya"
                },
                "aria": {
                    "sortAscending":  ": activate to sort column ascending",
                    "sortDescending": ": activate to sort column descending"
                }
            },
          
             // show the export datatable buttons
            dom: '<"p-l-0 col-md-6"l>B<"p-r-0 col-md-6"f>rt<"col-md-6 p-l-0"i><"col-md-6 p-r-0"p>',
            buttons: dtButtons([
                'pdfHtml5',
                'print',
                'colvis'
            ]),
        });

        // move the datatable buttons in the top-right corner and make them smaller
        table.buttons().each(function(button) {
            if (button.node.className.indexOf('buttons-columnVisibility') == -1)
            {
                button.node.className = button.node.className + " btn-sm";
            }
        });
        $(".dt-buttons").appendTo($('#datatable_button_stack' ));
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('backpack::layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>