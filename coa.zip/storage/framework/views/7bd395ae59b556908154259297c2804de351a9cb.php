<?php $__env->startSection('before_styles'); ?>

        <!-- include select2 css-->
        <link href="<?php echo e(asset('vendor/backpack/select2/select2.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('vendor/backpack/select2/select2-bootstrap-dick.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('vendor/adminlte/plugins/datepicker/datepicker3.css')); ?>" rel="stylesheet" type="text/css" />
        <link href="<?php echo e(asset('vendor/backpack/pnotify/pnotify.custom.min.css')); ?>" rel="stylesheet" type="text/css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('header'); ?>
	<section class="content-header">
	  <h1>
	    <span class="text-capitalize"><?php echo e($crud->entity_name_plural); ?></span>
	    <small><?php echo e(trans('backpack::crud.all')); ?> <span class="text-lowercase"><?php echo e($crud->entity_name_plural); ?></span> <?php echo e(trans('backpack::crud.in_the_database')); ?>.</small>
	  </h1>
	  <ol class="breadcrumb">
	    <li><a href="<?php echo e(url(config('backpack.base.route_prefix'), 'dashboard')); ?>"><?php echo e(trans('backpack::crud.admin')); ?></a></li>
	    <li><a href="<?php echo e(url($crud->route)); ?>" class="text-capitalize"><?php echo e($crud->entity_name_plural); ?></a></li>
	    <li class="active"><?php echo e(trans('backpack::crud.list')); ?></li>
	  </ol>
	</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div id="page-wrapper" style="width:65%; margin:auto">
            <div id="page-inner">
                <div class="row">
                    <div class="col-md-12">
                     <h2>Input Hafalan</h2>
                    </div>
                </div>
                <div class="panel panel-default">
                        <div class="panel-heading">
                             Hafalan Siswa
                        </div>
                                    <form role="form"style="padding-left:10px; margin-top:10px; padding-right:10px" action=<?php echo e(url('/hafalan/tambah')); ?> method='post' >
                                        <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>" >
                                            <div class="form-group">
                                                <label>Tanggal</label>
                                                <div class="input-group date" data-provide="datepicker">
                                                    <input type="text" class="form-control" id="datepicker" name="tanggal" >
                                                    <div class="input-group-addon">
                                                        <span class="glyphicon glyphicon-th"></span>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="form-group">
                                                <label>Nama Siswa</label>
                                                <select name="NIS" class="form-control select2" style="width:100%">
                                                    <?php $__currentLoopData = $crud->dataSiswa; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                  <option value="<?php echo e($data->NIS); ?>"><?php echo e($data->nama); ?></option>
                                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                <!-- <input type="text" class="form-control">
                                            <span class="input-group-btn">
                                                <button class="btn btn-default" type="button"><i class="fa fa-search"></i>
                                                </button>
                                            </span> -->
                                            </div>
                                            
                                            <div class="form-group">
                                                <label>Jenis</label>
                                                <select name="jenis" class="form-control">
                                                    <option value="ziadah">Ziadah</option>
                                                    <option value="murojaah">Murojaah</option>
                                                </select>
                                            </div>
                                            
                                            
                                            
                                            <div class="form-group">
                                                <label>Juz</label>
                                                <select name="surahAwal" class="form-control select2" style="width:100%">
                                                    <?php $__currentLoopData = $crud->dataSurah; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                  <option value="<?php echo e($data->id); ?>"><?php echo e($data->nama); ?></option>
                                                   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label>Dari Halaman</label>
                                                <input name="ayatAwal" class="form-control" />
                                            </div>
                                          
                                      
                                            
                                             
                                            <div class="form-group">
                                                <label>Sampai Halaman</label>
                                                <input name="ayatAkhir" class="form-control" />
                                            </div>
                                        
                                        <div class="form-group">
                                                <label>Nilai</label>
                                                <input name="nilai" class="form-control" />
                                            </div>
                                            <button type="submit" class="btn btn-primary" >Simpan</button>
                                            <a href="<?php echo e(url('/admin/hafalan')); ?>" class="btn btn-primary">Batal</a>
                                        
                                    </form>
                </div>

                </div>

                
                <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.0/jquery.min.js"></script>
                <script src="<?php echo e(asset('/vendor/adminlte/plugins/datepicker/bootstrap-datepicker.js')); ?>"></script>
                <script src="<?php echo e(asset('/vendor/backpack/select2/select2.js')); ?>"></script>
                <script type="text/javascript">
                    jQuery(document).ready(function($) {
                      $(".select2").select2();
                    });
                    $('#datepicker').datepicker({
                        format: 'dd/MM/yyyy',
                        endDate: '0d', 
                        todayBtn: "linked",
                        autoClose: true
                    });
                    
                </script>
                <script type="text/javascript">
                    jQuery(document).ready(function($) {

                      PNotify.prototype.options.styling = "bootstrap3";
                      PNotify.prototype.options.styling = "fontawesome";

                      // <?php $__currentLoopData = Alert::getMessages(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $type => $messages): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      //     // <?php $__currentLoopData = $messages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $message): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      //         <?php if($type == "error"): ?>
                      //             $(function(){
                      //           new PNotify({
                      //             title: 'Error',
                      //             text: "<?php echo e($message); ?>",
                      //             type: "<?php echo e($type); ?>",
                      //           });
                      //         });
                      //         <?php endif; ?>
                      //         <?php if($type == "success"): ?>
                      //             $(function(){
                      //           new PNotify({
                      //             title: 'Sukses',
                      //             text: "<?php echo e($message); ?>",
                      //             type: "<?php echo e($type); ?>",
                      //           });
                      //         });  
                      //         <?php endif; ?>
                      //     // <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      // <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    });
                  </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('backpack::layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>